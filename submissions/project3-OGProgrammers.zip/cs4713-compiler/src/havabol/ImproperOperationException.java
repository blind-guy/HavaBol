package havabol;

public class ImproperOperationException extends Exception {
	public ImproperOperationException(String message)
	{
		super(message);
	}
}
