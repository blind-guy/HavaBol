package havabol;

@SuppressWarnings("serial")
public class ScannerTokenFormatException extends Exception {
	public ScannerTokenFormatException(String message)
	{
		super(message);
	}
}
