package havabol;

public class DivideByZeroException extends Exception {
	public DivideByZeroException(String message) 
	{
		super(message);
	}
}
