package havabol;

public enum HavabolStructureType 
{
	PRIMITIVE,
	ARRAY
}
