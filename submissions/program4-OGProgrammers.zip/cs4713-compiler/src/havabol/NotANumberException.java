package havabol;

public class NotANumberException extends Exception {
	public NotANumberException(String message) {
		super(message);
	}
}
