package havabol;

public class ResultValueConversionException extends Exception 
{
	public ResultValueConversionException(String message)
	{
		super(message);
	}
}
